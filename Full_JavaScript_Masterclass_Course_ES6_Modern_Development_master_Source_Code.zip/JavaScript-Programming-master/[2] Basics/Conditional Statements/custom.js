"use strict";

var num1 = 314;
var num2 = 314;

if (num1 < num2)
{
	console.log("Num1 is less than Num2");
}
else if (num1 > num2)
{
	console.log("Num1 is greater than Num2");
}
else
{
	console.log("Default fallback code");
}