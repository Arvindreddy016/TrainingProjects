"use strict";

var var1 = 9;
var var2 = '9';

// Equal ==
console.log(var1 == var2);
// Equal ===
console.log(var1 === var2);

// Not Equal !=
console.log(var1 != var2);

// Greater than >
console.log(var1 > var2);

// Less than <
console.log(var1 < var2);

// Greater than or equal to >=
console.log(var1 >= var2);

// Less than or equal to <=
console.log(var1 <= var2);