"use strict";

var var1 = 10001;
var var2 = "Hello World"

console.log(typeof var1);
console.log(typeof var2);