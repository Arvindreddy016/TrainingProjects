"use strict";

var num1 = 27;
var num2 = 22;

// AND operator &
console.log(num1 & num2);

// 27 in binary

// 16 8 4 2 1
// 1  1 0 1 1

// 22 in binary

// 16 8 4 2 1
// 1  0 1 1 0

// 1  1 0 1 1
// 1  0 1 1 0
// 1  0 0 1 0