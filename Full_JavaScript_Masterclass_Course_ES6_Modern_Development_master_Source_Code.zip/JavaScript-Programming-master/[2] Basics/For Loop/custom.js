"use strict";

for (var i = 0; i <= 100; i += 2)
{
	console.log("This is position: " + i);
}








