"use strict";

// Assignment operator
var var1 = 9;
console.log(var1);

// Add Assignment operator
var var2 = 9;
var2 += 6;
console.log(var2);

// Subtract Assignment operator
var var3 = 9;
var3 -= 6;
console.log(var3);

// Multiplication Assignment operator
var var4 = 9;
var4 *= 6;
console.log(var4);

// Division Assignment operator
var var5 = 9;
var5 /= 6;
console.log(var5);

// Modulus Assignment operator
var var6 = 9;
var6 %= 6;
console.log(var6);






