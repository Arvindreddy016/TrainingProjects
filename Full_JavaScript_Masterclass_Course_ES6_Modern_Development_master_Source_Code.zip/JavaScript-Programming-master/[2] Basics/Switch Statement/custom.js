"use strict";

var awesomeVar = 0;

switch (awesomeVar)
{
	case 0:
	console.log("This is 0");
	break;

	case 1:
	console.log("This is 1");
	break;

	case 2:
	console.log("This is 2");
	break;

	case 3:
	console.log("This is 3");
	break;

	case 4:
	console.log("This is 4");
	break;

	case 5:
	console.log("This is 5");
	break;

	default:
	console.log("This is the default value");
	break;
}










