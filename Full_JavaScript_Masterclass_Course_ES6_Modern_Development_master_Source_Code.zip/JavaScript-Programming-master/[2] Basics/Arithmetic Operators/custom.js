"use strict";

// Addition operator
console.log(4 + 8);

// Subtraction operator
console.log(4 - 8);

// Multiplication operator
console.log(4 * 8);

// Division operator
console.log(4 / 8);

// Modulus operator
console.log(7 % 3);

var num = 10;

console.log(num);

// Increment operator
num++; // num = num + 1

console.log(num);

var num2 = 10;

console.log(num2);

// Decrement operator
num2--; // num2 = num2 - 1

console.log(num2);


var num3 = 10;

console.log(num3);

console.log(--num3);

console.log(num3);





