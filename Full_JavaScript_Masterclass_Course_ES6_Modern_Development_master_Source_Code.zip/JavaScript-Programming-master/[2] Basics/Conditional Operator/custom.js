"use strict";

var num1 = 100;
var num2 = 100;

var result = (num1 < num2) ? "yay" : "nay";

console.log(result);