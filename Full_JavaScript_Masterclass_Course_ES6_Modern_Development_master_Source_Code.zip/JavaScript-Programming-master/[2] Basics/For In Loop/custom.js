"use strict";

var amazingObject = {frahaan: 1, b: 2, c: 3, d: 4};

for (var item in amazingObject)
{
	console.log(item + " : " + amazingObject[item]);
}



