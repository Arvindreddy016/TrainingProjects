"use strict";

for (var i = 1000; i <= 100; i += 2)
{
	console.log("This is position for I: " + i);
}

var j = 1000;

while (j <= 100)
{
	console.log("This is position for J: " + j);
	j += 2;
}

var k = 1000;

do
{
	console.log("This is position for K: " + k);
	k += 2;
} while (k <= 100)




