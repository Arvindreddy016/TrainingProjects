"use strict";

console.log(navigator.javaEnabled());
console.log(navigator.onLine);
console.log(navigator.deviceMemory);
console.log(navigator.vendor);