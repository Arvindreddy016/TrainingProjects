"use strict";

EpicFunc();

function EpicFunc()
{
	console.log("Hello World");
}





