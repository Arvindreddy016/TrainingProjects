"use strict";

export function HelloWorld() {
  console.log("Hello World");
}
