"use strict";

import { HelloWorld } from "./custom.js";

HelloWorld();
