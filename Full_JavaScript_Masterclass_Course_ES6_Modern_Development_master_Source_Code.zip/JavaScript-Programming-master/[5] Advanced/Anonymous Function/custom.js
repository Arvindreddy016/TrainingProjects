"use strict";



var epicVar = function()
{
	console.log("Hello World");
}

epicVar();


