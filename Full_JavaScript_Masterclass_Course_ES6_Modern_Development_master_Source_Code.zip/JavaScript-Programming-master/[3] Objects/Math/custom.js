"use strict";


console.log(Math.PI);

console.log(Math.pow(12, 2));

console.log(Math.round(345.6));

console.log(Math.sqrt(144));
console.log(Math.sqrt(12));