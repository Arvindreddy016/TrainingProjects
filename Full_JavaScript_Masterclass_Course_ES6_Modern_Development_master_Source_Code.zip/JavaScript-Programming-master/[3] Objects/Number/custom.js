"use strict";

var i = new Number(67.463098);

console.log(i);
console.log(i.toPrecision(3));
console.log(i.toString());

console.log(Number.MAX_VALUE);